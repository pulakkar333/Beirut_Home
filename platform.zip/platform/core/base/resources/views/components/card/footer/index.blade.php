<div {{ $attributes->merge(['class' => 'card-footer']) }}>
    {{ $slot }}
</div>
