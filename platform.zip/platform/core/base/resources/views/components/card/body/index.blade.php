<div {{ $attributes->merge(['class' => 'card-body']) }}>
    {{ $slot }}
</div>
