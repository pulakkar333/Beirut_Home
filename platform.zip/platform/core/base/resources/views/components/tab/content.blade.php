<div {{ $attributes->merge(['class' => 'tab-content']) }}>
    {{ $slot }}
</div>
