<div {{ $attributes->merge(['class' => 'offcanvas-header']) }}>
    {{ $slot }}
</div>
