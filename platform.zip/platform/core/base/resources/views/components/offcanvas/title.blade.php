<h2 {{ $attributes->merge(['class' => 'offcanvas-title']) }}>{{ $slot }}</h2>
